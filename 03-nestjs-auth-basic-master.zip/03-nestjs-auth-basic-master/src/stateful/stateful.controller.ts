import { Controller } from '@nestjs/common';

@Controller('stateful')
export class StatefulController {}
